import { AutoHeightDirective } from './auto-height.directive';

describe('AutoHeightDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoHeightDirective();
    expect(directive).toBeTruthy();
  });
});
